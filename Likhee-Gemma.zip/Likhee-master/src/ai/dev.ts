import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-writing.ts';
import '@/ai/flows/improve-sentence.ts';