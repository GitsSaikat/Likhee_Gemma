import { LexicaEditor } from "@/components/lexica/lexica-editor";

export default function LexicaPage() {
  return (
    <LexicaEditor />
  );
}
